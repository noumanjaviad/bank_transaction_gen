 <div class="col-12 mt-5 container-fluid">
     <div class="bg-light rounded h-100 p-4">
         <h6 class="mb-4">Customer Table</h6>
         <div class="table-responsive">
         <table class="table table-bordered">
             <thead>
                 <tr>
                     <th scope="col">#</th>
                     <th scope="col">Customer Name</th>
                     <th scope="col">Bank</th>
                     <th scope="col">Account Number</th>
                     <th scope="col">IBAN</th>
                     <th scope="col">Account Type</th>
                     <th scope="col">Contact</th>
                     <th scope="col">Address</th>
                     <th scope="col">Action</th>
                 </tr>
             </thead>
             <tbody>
                 <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                     <tr>
                         <th scope="row"><?php echo e($loop->iteration); ?></th>
                         <td><?php echo e($customer->name); ?></td>
                         <td><?php echo e($customer->company->name); ?></td>
                         <td><?php echo e($customer->account_number); ?></td>
                         <td><?php echo e($customer->iban); ?></td>
                         <td><?php echo e($customer->type); ?></td>
                         <td><?php echo e($customer->contact); ?></td>
                         <td><?php echo e($customer->address); ?></td>
                         <td>
                             
                                <a href="<?php echo e(route('get_transaction_form',$customer->productid)); ?>"
                                 class="btn btn-success mb-2 btn-sm">Start Transaction</a>
                             <a href="<?php echo e(route('customers.edit', $customer->productid)); ?>"
                                 class="btn btn-warning btn-sm">Edit</a>
                             
                             <form action="<?php echo e(route('customers.destroy', $customer->productid)); ?>" method="POST"
                                style="display:inline;">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('DELETE'); ?>
                                 <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                             </form>

                         </td>
                     </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>
         </div>
         <div class="d-flex ">
            <?php echo e($customers->links()); ?>

        </div>
     </div>
 </div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tran_gen/resources/views/Admin/customer/show_customer.blade.php ENDPATH**/ ?>