<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="col-sm-12 col-xl-8">
            <div class="col-12 bg-light rounded h-100 p-4">
                <h6 class="mb-4">Find Transaction</h6>
                <form action="<?php echo e(route('search.transaction')); ?>" method="POST">
                    <input type="hidden" name="productid" value="<?php echo e($id); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <label for="companyid" class="col-sm-2 col-form-label">From Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="from_date">
                        </div>
                        
                    </div>

                    <div class="row mb-3">
                        <label for="name" class="col-sm-2 col-form-label">To Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="to_date">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-10 offset-sm-2">
                            <button type="submit" name="submit" class="btn btn-primary" target="_blank">Submit</button>
                            <button type="button" class="btn btn-secondary" onclick="window.location.href='your-cancel-url';">Cancel</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tran_gen/resources/views/Admin/search.blade.php ENDPATH**/ ?>