<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-12 mt-5 container-fluid">
        <div class="bg-light rounded h-100 p-4">
            <h6 class="mb-4">NBD Customer</h6>
            <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Customer Name</th>
                        <th scope="col">Bank</th>
                        <th scope="col">Account Number</th>
                        <th scope="col">IBAN</th>
                        <th scope="col">Account Type</th>
                        <th scope="col">Contact</th>
                        <th scope="col">Address</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $NbdCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nbdCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($nbdCustomer->name); ?></td>
                            <td><?php echo e($nbdCustomer->company->name); ?></td>
                            <td><?php echo e($nbdCustomer->account_number); ?></td>
                            <td><?php echo e($nbdCustomer->iban); ?></td>
                            <td><?php echo e($nbdCustomer->type); ?></td>
                            <td><?php echo e($nbdCustomer->contact); ?></td>
                            <td><?php echo e($nbdCustomer->address); ?></td>
                            <td>
                                <a href="<?php echo e(route('search',$nbdCustomer->productid)); ?>" class="btn btn-success  mb-2 btn-sm "  id="downloadPDF" >Generate PDF</a>
                                
                                

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
            <div class="d-flex justify-content-center">
                <?php echo e($NbdCustomers->links()); ?>

            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tran_gen/resources/views/Admin/nbd/show_nbd_customer.blade.php ENDPATH**/ ?>