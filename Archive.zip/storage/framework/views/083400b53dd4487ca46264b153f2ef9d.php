<div class="bg-light rounded-top p-4">
    <div class="row">
        <div class="col-12">
            
            <p>ADMIN</p>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tran_gen/resources/views/partials/header.blade.php ENDPATH**/ ?>